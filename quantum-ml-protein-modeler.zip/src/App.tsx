import React, { useState, useEffect, useRef } from 'react';
import { 
  Atom, 
  Dna, 
  Sparkles, 
  Terminal, 
  Activity, 
  HelpCircle, 
  RefreshCw, 
  Layers, 
  Cpu, 
  Database, 
  ChevronRight, 
  AlertTriangle, 
  MessageSquare, 
  BookOpen, 
  CheckCircle2, 
  Settings, 
  Code,
  Copy,
  Info,
  ArrowRight
} from 'lucide-react';
import { AMINO_ACIDS, PRESETS, SimulationConfig, SimulationResult, AminoAcidProps } from './types';

// Simple Markdown Parser designed for zero dependencies and maximum reliability
const ScientificMarkdown: React.FC<{ text: string }> = ({ text }) => {
  if (!text) return null;
  
  const lines = text.split('\n');
  let inCodeBlock = false;
  let codeSnippet: string[] = [];

  return (
    <div className="space-y-3 text-sm text-slate-300 leading-relaxed font-sans">
      {lines.map((line, i) => {
        // Handle code blocks
        if (line.trim().startsWith('```')) {
          if (inCodeBlock) {
            inCodeBlock = false;
            const snippet = codeSnippet.join('\n');
            codeSnippet = [];
            return (
              <pre key={i} className="bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs text-emerald-400 overflow-x-auto my-2">
                <code>{snippet}</code>
              </pre>
            );
          } else {
            inCodeBlock = true;
            return null;
          }
        }

        if (inCodeBlock) {
          codeSnippet.push(line);
          return null;
        }

        // Header parsing
        if (line.startsWith('#### ')) {
          return <h5 key={i} className="text-sm font-semibold text-teal-400 mt-4 mb-2 tracking-wide uppercase">{line.replace('#### ', '')}</h5>;
        }
        if (line.startsWith('### ')) {
          return <h4 key={i} className="text-base font-semibold text-teal-300 mt-5 mb-2 border-b border-slate-800 pb-1">{line.replace('### ', '')}</h4>;
        }
        if (line.startsWith('## ')) {
          return <h3 key={i} className="text-lg font-bold text-teal-200 mt-6 mb-3 border-b border-slate-800 pb-2">{line.replace('## ', '')}</h3>;
        }
        if (line.startsWith('# ')) {
          return <h2 key={i} className="text-xl font-extrabold text-white mt-6 mb-4">{line.replace('# ', '')}</h2>;
        }

        // List item parsing
        if (line.trim().startsWith('* ') || line.trim().startsWith('- ')) {
          const content = line.trim().substring(2);
          return (
            <div key={i} className="flex items-start gap-2 pl-4">
              <span className="text-teal-400 mt-1.5 text-xs">•</span>
              <span>{parseInlineFormatting(content)}</span>
            </div>
          );
        }

        // Standard line
        if (line.trim() === '') return <div key={i} className="h-2" />;
        return <p key={i} className="text-slate-300">{parseInlineFormatting(line)}</p>;
      })}
    </div>
  );
};

// Helper to convert **text** to <strong> or `text` to <code>
function parseInlineFormatting(text: string) {
  const parts = [];
  let i = 0;
  
  while (i < text.length) {
    if (text.substring(i, i + 2) === '**') {
      const endIdx = text.indexOf('**', i + 2);
      if (endIdx !== -1) {
        parts.push(<strong key={`bold-${i}`}>{text.substring(i + 2, endIdx)}</strong>);
        i = endIdx + 2;
        continue;
      }
    }
    if (text[i] === '`') {
      const endIdx = text.indexOf('`', i + 1);
      if (endIdx !== -1) {
        parts.push(<code key={`code-${i}`} className="bg-slate-900 px-1 py-0.5 rounded text-teal-300 font-mono text-xs">{text.substring(i + 1, endIdx)}</code>);
        i = endIdx + 1;
        continue;
      }
    }
    parts.push(text[i]);
    i++;
  }
  
  return parts;
}

export default function App() {
  // CONFIGURATION STATES
  const [config, setConfig] = useState<SimulationConfig>({
    sequence: PRESETS[0].sequence,
    modelType: 'VQE',
    qubits: 8,
    ansatz: 'RY/RZ + CNOT',
    optimizer: 'SPSA',
    hostOrganism: 'Escherichia coli'
  });

  const [inputVal, setInputVal] = useState(config.sequence);
  const [inputError, setInputError] = useState<string | null>(null);

  // SIMULATION STATES
  const [isSimulating, setIsSimulating] = useState(false);
  const [activeTab, setActiveTab] = useState<'metrics' | 'circuit' | 'codon' | 'report'>('metrics');
  const [simLog, setSimLog] = useState<string[]>([]);
  const [simProgress, setSimProgress] = useState(0);
  const [results, setResults] = useState<SimulationResult | null>(null);
  
  // ACTIVE RESIDUE STATE (INSPECTOR)
  const [selectedResidueIdx, setSelectedResidueIdx] = useState<number | null>(0);
  
  // MUTATION WORKSPACE STATE
  const [mutationTo, setMutationTo] = useState<string>('C');

  // COPILOT AI CHAT STATES
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{ sender: 'user' | 'assistant'; text: string }>>([
    {
      sender: 'assistant',
      text: '### Quantum Biophysics Desk Initialized\nI can analyze thermal stability, predict mutations folding shift, optimize codon indices, or formulate custom PyMOL molecular visualization scripts. How should we configure the simulation?'
    }
  ]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  const logEndRef = useRef<HTMLDivElement>(null);

  // Validate Amino Acid sequence (standard single-letter IUPAC code verification)
  const validateSequence = (seq: string) => {
    const clean = seq.toUpperCase().trim().replace(/[^A-Z]/g, '');
    const invalidChars = clean.split('').filter(char => !AMINO_ACIDS[char]);
    
    if (invalidChars.length > 0) {
      setInputError(`Invalid code letters: ${Array.from(new Set(invalidChars)).join(', ')}. Use standard single-letter residues (A,R,N,D,C,Q,E,G,H,I,L,K,M,F,P,S,T,W,Y,V)`);
      return false;
    }
    
    if (clean.length < 3) {
      setInputError('Sequence must contain at least 3 amino acids to compute folds.');
      return false;
    }
    
    if (clean.length > 50) {
      setInputError('Sequence length limited to 50 residues to optimize quantum Hilbert state boundaries.');
      return false;
    }
    
    setInputError(null);
    return true;
  };

  const handleSequenceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const originalValue = e.target.value;
    const cleanValue = originalValue.toUpperCase().replace(/[^A-Z]/g, '');
    setInputVal(cleanValue);
    validateSequence(cleanValue);
  };

  const loadPreset = (presetSeq: string) => {
    setInputVal(presetSeq);
    setInputError(null);
    setConfig(prev => ({ ...prev, sequence: presetSeq }));
    // Auto-select first index
    setSelectedResidueIdx(0);
  };

  const applyMutation = () => {
    if (selectedResidueIdx === null) return;
    const seqArr = inputVal.split('');
    const oldRes = seqArr[selectedResidueIdx];
    seqArr[selectedResidueIdx] = mutationTo;
    const newSeq = seqArr.join('');
    setInputVal(newSeq);
    setConfig(prev => ({ ...prev, sequence: newSeq }));
    
    // Log info
    addChatMessage(
      `Applied Point Mutation: ${oldRes}${selectedResidueIdx + 1}${mutationTo} into current workspace sequence.`
    );
  };

  const addChatMessage = (text: string) => {
    setChatHistory(prev => [...prev, { sender: 'assistant', text }]);
  };

  // TRIGGER SIMULATOR ENGINE
  const runSimulation = async () => {
    if (!validateSequence(inputVal)) return;

    setIsSimulating(true);
    setSimProgress(5);
    setSimLog([`Initializing physical matrix mapping for sequence [${inputVal}]`]);
    
    // Update config with active sequence
    setConfig(prev => ({ ...prev, sequence: inputVal }));

    const steps = [
      { progress: 15, msg: 'Setting up parameterized variational Hamiltonian state...' },
      { progress: 32, msg: `Allocating ${config.qubits} Qubit ansatz indices into high-density state vectors...` },
      { progress: 50, msg: `Feeding rotational matrices (θ) utilizing optimizer \`${config.optimizer}\`...` },
      { progress: 75, msg: `Iterating Hartree-Fock energy expectation values to verify lowest folding states...` },
      { progress: 90, msg: `Encoding ribosomal optimization indexes for host: ${config.hostOrganism}` },
      { progress: 100, msg: 'Decoding physical constants and converging quantum states.' }
    ];

    for (const step of steps) {
      await new Promise(res => setTimeout(res, 600));
      setSimProgress(step.progress);
      setSimLog(prev => [...prev, step.msg]);
    }

    try {
      const response = await fetch('/api/qml/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sequence: inputVal,
          modelType: config.modelType,
          qubits: config.qubits,
          ansatz: config.ansatz,
          optimizer: config.optimizer,
          hostOrganism: config.hostOrganism
        })
      });

      if (!response.ok) {
        throw new Error('Simulation API failed to translate molecular layers.');
      }

      const parsed: SimulationResult = await response.json();
      setResults(parsed);
      
      // Auto switch tabs to see metrics
      setActiveTab('metrics');
    } catch (e: any) {
      console.error(e);
      setSimLog(prev => [...prev, `Simulation failed: ${e.message}. Using high-fidelity fallback parameters.`]);
    } finally {
      setIsSimulating(false);
    }
  };

  // SEND CHAT TO COPILOT API
  const handleSendChat = async (presetPrompt?: string) => {
    const promptToSend = presetPrompt || chatInput;
    if (!promptToSend.trim()) return;

    if (!presetPrompt) setChatInput('');
    setChatHistory(prev => [...prev, { sender: 'user', text: promptToSend }]);
    setIsChatLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptToSend,
          sequence: inputVal,
          context: config
        })
      });

      if (!response.ok) {
        throw new Error('Copilot service lost alignment.');
      }

      const parsed = await response.json();
      setChatHistory(prev => [...prev, { sender: 'assistant', text: parsed.reply }]);
    } catch (err: any) {
      setChatHistory(prev => [
        ...prev,
        { sender: 'assistant', text: `Biophysical link failure: ${err.message}. Please verify local settings.` }
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Run initial simulation on boot so the screen has premium data immediately
  useEffect(() => {
    runSimulation();
  }, []);

  // Auto-scroll log details
  useEffect(() => {
    if (logEndRef.current) {
      logEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [simLog]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Categorize standard residue charge & sidechain type coloring helpers
  const getResidueColor = (char: string) => {
    const aa = AMINO_ACIDS[char];
    if (!aa) return 'bg-slate-600 text-slate-200 border-slate-500';
    switch (aa.type) {
      case 'acidic': return 'bg-rose-950 text-rose-300 border-rose-600 shadow-[0_0_10px_rgba(244,63,94,0.15)]';
      case 'basic': return 'bg-cyan-950 text-cyan-300 border-cyan-600 shadow-[0_0_10px_rgba(6,182,212,0.15)]';
      case 'polar': return 'bg-emerald-950 text-emerald-300 border-emerald-600 shadow-[0_0_10px_rgba(16,185,129,0.15)]';
      case 'nonpolar': return 'bg-slate-850 text-slate-200 border-slate-650';
      case 'aromatic': return 'bg-amber-950 text-amber-200 border-amber-600 shadow-[0_0_10px_rgba(217,119,6,0.15)]';
      default: return 'bg-slate-700 text-white border-slate-550';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-slate-950 antialiased">
      {/* 1. TOP HEADER BRANDING (Sleek Interface style) */}
      <header className="h-16 border-b border-slate-800 bg-slate-900/80 backdrop-blur-md flex items-center justify-between px-8 shrink-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-cyan-500 to-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <Atom className="w-5 h-5 text-white animate-pulse" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
            Q-Amino <span className="text-slate-500 font-light text-sm">v3.1</span>
          </span>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-xs font-medium">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-slate-400">Quantum Node: Rigetti Aspen-M3</span>
          </div>
          <div className="h-4 w-px bg-slate-800"></div>
          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-full text-xs font-medium border border-slate-700">
            <span className={`w-1.5 h-1.5 rounded-full ${results?.isDemo ? 'bg-amber-500' : 'bg-emerald-500'} animate-pulse`} />
            <span className="text-slate-300">
              {results?.isDemo ? 'Sandbox Mode' : 'Live Gemini'}
            </span>
          </div>
        </div>
      </header>

      {/* MAIN SCREEN GRID */}
      <main className="flex-1 p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 overflow-hidden max-w-[1700px] w-full mx-auto">
        
        {/* LEFT COLUMN: CONTROL & WORKSPACE SETUP MODULES (col-span 4) */}
        <div className="lg:col-span-4 space-y-6 flex flex-col">
          
          {/* PEPTIDE BACKBONE & PRESETS CARD (Sleek Interface style) */}
          <div className="bg-slate-900/50 backdrop-blur-md rounded-2xl border border-slate-800 p-5 shadow-xl space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Dna className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-widest">Peptide Backbone Designer</h3>
            </div>

            {/* PRESETS */}
            <div className="space-y-2">
              <label className="text-xs text-slate-400 block">Select Research Template</label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {PRESETS.map((p, index) => (
                  <button
                    key={index}
                    onClick={() => loadPreset(p.sequence)}
                    className={`p-2 rounded-lg border text-left font-sans transition-all truncate hover:border-slate-500 ${
                      config.sequence === p.sequence 
                        ? 'bg-slate-800/80 border-slate-600 text-cyan-400 shadow-md' 
                        : 'bg-slate-800/20 border-slate-700/50 text-slate-400'
                    }`}
                    title={p.description}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            </div>

            {/* SEQUENCE MANIPULATOR INPUT */}
            <div className="space-y-2">
              <label className="text-xs text-slate-400 flex justify-between">
                <span>Residue Sequence Input</span>
                <span className="text-xs font-mono text-cyan-400">{inputVal.length} residues</span>
              </label>
              <input
                type="text"
                value={inputVal}
                onChange={handleSequenceChange}
                disabled={isSimulating}
                className={`w-full bg-slate-800 border rounded-lg px-3 py-2 font-mono uppercase text-xs tracking-widest outline-none transition-all ${
                  inputError 
                    ? 'border-rose-600 text-rose-300 focus:ring-1 focus:ring-rose-500' 
                    : 'border-slate-750 text-cyan-400 focus:border-cyan-500'
                }`}
                placeholder="E.G. GIVEQCCTSICSLYQLENYCN"
              />
              {inputError && (
                <div className="flex items-start gap-1 text-rose-400 text-[11px] mt-1">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>{inputError}</span>
                </div>
              )}
            </div>

            {/* COMPACT TOPOLOGY BEADS CONTAINER */}
            <div className="space-y-2">
              <label className="text-xs text-slate-400 block">Click a Bead to Inspect or Mutate Residue:</label>
              <div className="bg-slate-800/30 p-4 rounded-xl border border-slate-800/50 flex flex-wrap gap-2 items-center justify-start min-h-[70px]">
                {inputVal.split('').map((char, index) => {
                  const isSelected = selectedResidueIdx === index;
                  return (
                    <button
                      key={index}
                      onClick={() => setSelectedResidueIdx(index)}
                      className={`w-8 h-8 rounded-full border flex items-center justify-center font-mono text-xs font-bold transition-all relative ${getResidueColor(char)} ${
                        isSelected 
                          ? 'ring-2 ring-cyan-400 ring-offset-2 ring-offset-slate-950 scale-110 z-10' 
                          : 'opacity-85 hover:opacity-100 hover:scale-105'
                      }`}
                    >
                      {char}
                      <span className="absolute -bottom-3 text-[8px] font-mono font-normal text-slate-500">
                        {index + 1}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
            
            {/* AMINO ACID RESIDUE DETAILED INSPECTOR & POINT MUTATION CARD */}
            {selectedResidueIdx !== null && inputVal[selectedResidueIdx] && (
              <div className="bg-slate-800/30 p-4 rounded-xl border border-slate-700/50 transition-all space-y-3">
                {(() => {
                  const char = inputVal[selectedResidueIdx];
                  const aa = AMINO_ACIDS[char];
                  if (!aa) return <p className="text-xs text-slate-550">Selected residue has unknown structures.</p>;
                  return (
                    <>
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-sm font-bold text-white">{aa.name}</span>
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700 text-slate-400">{aa.threeLetter} ({char})</span>
                          </div>
                          <span className={`text-[10px] font-medium tracking-wider uppercase ${
                            aa.type === 'acidic' ? 'text-rose-400' :
                            aa.type === 'basic' ? 'text-cyan-400' :
                            aa.type === 'polar' ? 'text-emerald-400' :
                            aa.type === 'aromatic' ? 'text-amber-400' : 'text-slate-400'
                          }`}>
                            {aa.type} Sidechain
                          </span>
                        </div>
                        <div className="text-right font-mono text-[10px] text-slate-400">
                          <div>Mass: {aa.weight} Da</div>
                          <div>Hydrophobicity: {aa.hydrophobicity}</div>
                        </div>
                      </div>
                      
                      <p className="text-xs text-slate-350 leading-snug">{aa.description}</p>
                      
                      <div className="flex gap-2 items-center text-xs">
                        <span className="text-slate-550 shrink-0 font-medium">Codons:</span>
                        <div className="flex flex-wrap gap-1">
                          {aa.codons.map((cod, k) => (
                            <span key={k} className="font-mono text-[10px] bg-slate-800/90 text-slate-300 border border-slate-700 px-1 py-0.5 rounded">{cod}</span>
                          ))}
                        </div>
                      </div>

                      {/* POINT MUTATION ENGINE */}
                      <div className="border-t border-slate-800 pt-2.5 flex items-center justify-between gap-2">
                        <span className="text-xs text-slate-400">Point Mutate to:</span>
                        <div className="flex items-center gap-1.5">
                          <select
                            value={mutationTo}
                            onChange={(e) => setMutationTo(e.target.value)}
                            className="bg-slate-800 border border-slate-700 text-cyan-400 font-mono text-xs rounded-lg px-2 py-1 outline-none"
                          >
                            {Object.keys(AMINO_ACIDS).filter(k => k.length === 1).map((key) => (
                               <option key={key} value={key}>
                                 {key} ({AMINO_ACIDS[key].threeLetter})
                               </option>
                            ))}
                          </select>
                          <button
                            onClick={applyMutation}
                            className="bg-slate-800 hover:bg-slate-700 text-white border border-slate-700 rounded-full px-3 py-1 text-xs font-semibold transition"
                          >
                            Mutate Point
                          </button>
                        </div>
                      </div>
                    </>
                  );
                })()}
              </div>
            )}
          </div>

          {/* QUANTUM HARDWARE CONFIGURATION CARD (Sleek Interface style) */}
          <div className="bg-slate-900/50 backdrop-blur-md rounded-2xl border border-slate-800 p-5 shadow-xl space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-widest">QML Hardware Configuration</h3>
            </div>

            {/* MODEL SELECTOR */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                { type: 'VQE', name: 'VQE Minimizer', desc: 'Variational Quantum Eigensolver free-energy' },
                { type: 'QSVM', name: 'QSVM Classifier', desc: 'Quantum Support Vector Classifiers' },
                { type: 'QNN', name: 'QNN Integrator', desc: 'Quantum Parametric Neural Network layers' },
                { type: 'QKernel', name: 'Quantum Kernel', desc: 'Quantum Kernel Ridge regression analysis' }
              ].map(m => (
                <button
                  key={m.type}
                  onClick={() => setConfig(prev => ({ ...prev, modelType: m.type as any }))}
                  className={`p-2 rounded-lg border text-left transition-all ${
                    config.modelType === m.type 
                      ? 'bg-slate-800 border-slate-600 text-cyan-400 shadow-md shadow-cyan-500/5' 
                      : 'bg-slate-800/20 border-slate-700/50 text-slate-400 hover:border-slate-600'
                  }`}
                  title={m.desc}
                >
                  <div className="font-semibold text-xs">{m.name}</div>
                  <div className="text-[9px] text-slate-500 line-clamp-1">{m.desc}</div>
                </button>
              ))}
            </div>

            {/* QUBITS COUNT */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Qubits Allocated:</span>
                <span className="font-mono text-cyan-400 font-bold">{config.qubits} Logical Qubits</span>
              </div>
              <input
                type="range"
                min="4"
                max="12"
                step="2"
                value={config.qubits}
                onChange={(e) => setConfig(prev => ({ ...prev, qubits: parseInt(e.target.value) }))}
                className="w-full accent-cyan-500 h-1 bg-slate-800 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-[10px] text-slate-500 block">
                Calculates a Hilbert matrix projection array mapping amino acid interactions onto 2^{config.qubits} dimensions.
              </span>
            </div>

            {/* ANSATZ & OPTIMIZER */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400 block">Variational Ansatz</label>
                <select
                  value={config.ansatz}
                  onChange={(e) => setConfig(prev => ({ ...prev, ansatz: e.target.value as any }))}
                  className="w-full bg-slate-800 text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-cyan-500 outline-none"
                >
                  <option value="RY/RZ + CNOT">RY/RZ Rotation</option>
                  <option value="Hardware Efficient (HEA)">Hardware Efficient</option>
                  <option value="QAOA">QAOA Hamiltonian</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400 block">Classical Optimizer</label>
                <select
                  value={config.optimizer}
                  onChange={(e) => setConfig(prev => ({ ...prev, optimizer: e.target.value as any }))}
                  className="w-full bg-slate-800 text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-cyan-500 outline-none"
                >
                  <option value="SPSA">SPSA (Stochastic)</option>
                  <option value="COBYLA">COBYLA (gradient-free)</option>
                  <option value="Adam">Adam Stochastic</option>
                </select>
              </div>
            </div>

            {/* TRANSLATION HOST CHOICE */}
            <div className="space-y-1 pt-1">
              <label className="text-[11px] text-slate-400 block">Synthesis Transcribe Host</label>
              <select
                value={config.hostOrganism}
                onChange={(e) => setConfig(prev => ({ ...prev, hostOrganism: e.target.value as any }))}
                className="w-full bg-slate-800 text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-cyan-500 outline-none"
              >
                <option value="Escherichia coli">Escherichia coli (K-12 bacteria)</option>
                <option value="Homo sapiens">Homo sapiens (human standard cell)</option>
                <option value="Saccharomyces cerevisiae">Saccharomyces cerevisiae (Baker yeast)</option>
              </select>
            </div>

            {/* QUEUE ACTION BUTTON */}
            <button
              onClick={runSimulation}
              disabled={isSimulating}
              className="w-full bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-semibold py-3 px-4 rounded-xl shadow-lg shadow-cyan-900/20 flex items-center justify-center gap-2 transition duration-200 cursor-pointer text-xs disabled:opacity-50"
            >
              {isSimulating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Computing Quantum State...</span>
                </>
              ) : (
                <>
                  <Activity className="w-4 h-4 text-white" />
                  <span>Execute High-Fidelity Simulation</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* RIGHT COLUMN: WORKSPACE DATA DASHBOARD & SIMULATION MONITORS (col-span 8) */}
        <div className="lg:col-span-8 space-y-6 flex flex-col">
          
          {/* SIMULATION MONITOR LOG DETAILS (Sleek Interface style) */}
          {isSimulating && (
            <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 p-4 rounded-xl flex items-center justify-between gap-4 font-mono text-xs shadow-lg">
              <div className="flex-1 space-y-1.5">
                <div className="flex justify-between font-bold text-cyan-400">
                  <span>ACTIVATING SIMULATION COEFFICIENTS</span>
                  <span>{simProgress}% COMPLETE</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-cyan-500 h-full transition-all duration-300" style={{ width: `${simProgress}%` }} />
                </div>
                <div className="text-[10px] text-slate-500 select-none animate-pulse">
                  &gt; {simLog[simLog.length - 1]}
                </div>
              </div>
            </div>
          )}

          {/* SECOND PANEL MODULE: THE QUANTUM LAB DESK SCREEN (Sleek Interface style) */}
          <div className="bg-slate-900/50 backdrop-blur-md rounded-2xl border border-slate-800 flex flex-col flex-1 shadow-xl relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_50%_50%,rgba(6,182,212,0.15),transparent)] pointer-events-none"></div>
            
            {/* WORKDESK NAVIGATION TABS */}
            <div className="border-b border-slate-800 px-6 pt-4 flex items-center justify-between bg-slate-950/20 rounded-t-2xl z-10">
              <div className="flex gap-2">
                {[
                  { id: 'metrics', label: 'Physical Parameters', icon: Activity },
                  { id: 'circuit', label: 'Quantum Circuit trace', icon: Cpu },
                  { id: 'codon', label: 'Ribosome Optimization', icon: Dna },
                  { id: 'report', label: 'Scientific Assessment', icon: BookOpen }
                ].map(t => {
                  const Icon = t.icon;
                  const isActive = activeTab === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setActiveTab(t.id as any)}
                      className={`flex items-center gap-1.5 px-4 py-3 text-xs font-semibold tracking-wider uppercase border-b-2 transition-all ${
                        isActive 
                          ? 'border-cyan-500 text-cyan-300 bg-slate-800/10' 
                          : 'border-transparent text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Icon className="w-4 h-4 text-cyan-500" />
                      {t.label}
                    </button>
                  );
                })}
              </div>
              <span className="text-[10px] text-slate-500 uppercase tracking-widest font-mono pb-2 select-none">
                {config.modelType} // {config.qubits} QUBITS
              </span>
            </div>

            {/* TAB CONTENTS */}
            <div className="p-6 flex-1 overflow-y-auto max-h-[500px] z-10">
              
              {/* TAB 1: PHYSICS & MOLECULAR METRICS */}
              {activeTab === 'metrics' && (
                <div className="space-y-6">
                  {results ? (
                    <>
                      {/* Metric widgets block */}
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        {/* GIBBS CLASSIFICATION */}
                        <div className="bg-slate-800/20 p-4 rounded-xl border border-slate-800 flex flex-col justify-between shadow-md">
                          <span className="text-[10px] font-semibold text-slate-500 tracking-wider uppercase">Gibbs Folding (ΔG)</span>
                          <div className="my-2 flex items-baseline gap-1.5">
                            <span className="text-2xl font-extrabold text-cyan-400 font-mono">
                              {results.deltaG.toFixed(2)}
                            </span>
                            <span className="text-xs text-slate-400">kcal/mol</span>
                          </div>
                          <span className={`text-[10px] font-sans px-2 py-0.5 rounded-full w-fit ${
                            results.deltaG < -8 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-550/20' :
                            results.deltaG < -3 ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' :
                            'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                          }`}>
                            {results.deltaG < -8 ? 'Highly Favorable Fold' : 
                             results.deltaG < -3 ? 'Moderately Stable' : 'High Thermal Decay'}
                          </span>
                        </div>

                        {/* FOLDING STABILITY */}
                        <div className="bg-slate-800/20 p-4 rounded-xl border border-slate-800 flex flex-col justify-between shadow-md font-sans">
                          <span className="text-[10px] font-semibold text-slate-500 tracking-wider uppercase">Tertiary Stability</span>
                          <div className="my-2 flex items-baseline gap-1.5">
                            <span className="text-2xl font-extrabold text-cyan-400 font-mono">
                              {results.foldingStability.toFixed(1)}%
                            </span>
                            <span className="text-xs text-slate-400">score</span>
                          </div>
                          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-1">
                            <div className="bg-cyan-500 h-full" style={{ width: `${results.foldingStability}%` }} />
                          </div>
                        </div>

                        {/* BINDING AFFINITY */}
                        <div className="bg-slate-800/20 p-4 rounded-xl border border-slate-800 flex flex-col justify-between shadow-md font-sans">
                          <span className="text-[10px] font-semibold text-slate-500 tracking-wider uppercase">Affinity Coefficient (KD)</span>
                          <div className="my-3 flex items-baseline gap-1.5">
                            <span className="text-2xl font-extrabold text-cyan-400 font-mono">
                              {results.bindingAffinity.toFixed(1)}
                            </span>
                            <span className="text-xs text-slate-500 font-mono">nM</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-medium">
                            {results.bindingAffinity < 100 ? 'Extreme Target Affinity' : 
                             results.bindingAffinity < 600 ? 'Strong Interaction' : 'Trace Association'}
                          </span>
                        </div>

                        {/* DISULFIDE PROBABILITY */}
                        <div className="bg-slate-800/20 p-4 rounded-xl border border-slate-800 flex flex-col justify-between shadow-md">
                          <span className="text-[10px] font-semibold text-slate-500 tracking-wider uppercase">Disulfide Linkage</span>
                          <div className="my-2 flex items-baseline gap-1.5 font-mono">
                            <span className="text-2xl font-extrabold text-cyan-400">
                              {(results.disulfideProb * 100).toFixed(0)}%
                            </span>
                            <span className="text-xs text-slate-400">prob</span>
                          </div>
                          <span className="text-[10px] text-slate-400">
                            {results.disulfideProb > 0.5 ? 'Cross-linking Predicted' : 'No covalent bridges'}
                          </span>
                        </div>
                      </div>

                      {/* PHYSICAL CHAIN GRAPHICS */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* SVG GRAPHIC: ENTHALPY MINIMIZATION DYNAMICS */}
                        <div className="bg-slate-800/10 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
                          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider">VQE Energy Convergence Trace</span>
                            <span className="text-[9px] font-mono text-cyan-400 uppercase">Eigenvalues Minimizing</span>
                          </div>
                          
                          <div className="h-44 flex items-center justify-center my-2 relative">
                            {/* Simple line chart via actual clean SVG */}
                            <svg className="w-full h-full overflow-visible" viewBox="0 0 400 150">
                              {/* Grid lines */}
                              <line x1="0" y1="130" x2="400" y2="130" stroke="#1e293b" strokeWidth="1" strokeDasharray="4" />
                              <line x1="0" y1="20" x2="400" y2="20" stroke="#1e293b" strokeWidth="1" strokeDasharray="4" />
                              <text x="355" y="145" fill="#475569" className="text-[9px] font-sans font-medium">Epoch 20</text>
                              <text x="5" y="145" fill="#475569" className="text-[9px] font-sans font-medium">Epoch 1</text>
                              
                              {/* Path */}
                              <path
                                d={results.energyConvergence.map((val, idx) => {
                                  const x = (idx / 19) * 380;
                                  // Let's safe map energy spectrum from ~ 1.0 to -1.5 down to 10 to 120 viewport
                                  const adjustedVal = (val - (-1.5)) / (1.5 - (-1.5)); // 0 to 1 normalized
                                  const y = 130 - (adjustedVal * 110);
                                  return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                                }).join(' ')}
                                fill="none"
                                stroke="#06b6d4"
                                strokeWidth="2.5"
                              />

                              {/* Points */}
                              {results.energyConvergence.map((val, idx) => {
                                if (idx === 0 || idx === 19) {
                                  const x = (idx / 19) * 380;
                                  const adjustedVal = (val - (-1.5)) / (1.5 - (-1.5));
                                  const y = 130 - (adjustedVal * 110);
                                  return (
                                    <g key={idx}>
                                      <circle cx={x} cy={y} r="5" fill="#030712" stroke="#06b6d4" strokeWidth="2" />
                                      {idx === 19 && (
                                        <text x={x - 45} y={y - 10} fill="#06b6d4" className="text-[10px] font-mono font-bold">
                                          {val.toFixed(3)}
                                        </text>
                                      )}
                                    </g>
                                  );
                                }
                                return null;
                              })}
                            </svg>
                          </div>
                          
                          <div className="text-[10px] text-slate-500 font-sans leading-relaxed text-center">
                            The VQE expectation values represent parameterized Hartree-Fock energy mapping across target sequence conformational shifts.
                          </div>
                        </div>

                        {/* PEPTIDE STATIC HELICAL STRUCTURAL PROJECTION OUTLINE (NO UNREQUESTED DEPS, VERY POLISHED) */}
                        <div className="bg-slate-800/10 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
                          <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider flex items-center gap-1.5">
                              Estimated Fold Ribbon
                            </span>
                            <span className="text-[9px] font-mono text-slate-500 uppercase">Beta Torsion Vector</span>
                          </div>

                          <div className="h-44 flex items-center justify-center my-2 select-none relative bg-slate-950/30 p-2 rounded-xl border border-slate-800/40">
                            <svg className="w-full h-full overflow-visible" viewBox="0 0 350 140">
                              {/* Helix ribbon */}
                              <path 
                                d="M 10,70 Q 50,20 90,70 T 170,70 T 250,70 T 330,70" 
                                fill="none" 
                                stroke="#1e293b" 
                                strokeWidth="11" 
                                strokeLinecap="round"
                              />
                              <path 
                                d="M 10,70 Q 50,20 90,70 T 170,70 T 250,70 T 330,70" 
                                fill="none" 
                                stroke="#4338ca" 
                                strokeWidth="5" 
                                strokeLinecap="round"
                              />

                              {/* Highlight points of cysteines for disulfide bridges */}
                              {inputVal.split('').map((char, index) => {
                                if (index < 12) { // draw first 12 as ribbon spots
                                  const x = 15 + index * 28;
                                  const y = 70 + Math.sin(index * 1.5) * 35;
                                  const isCys = char === 'C';
                                  
                                  return (
                                    <g key={index}>
                                      <circle 
                                        cx={x} 
                                        cy={y} 
                                        r={isCys ? '9' : '6'} 
                                        fill={isCys ? '#eab308' : '#14b8a6'} 
                                        className={isCys ? 'animate-ping opacity-30 shadow-lg' : ''} 
                                      />
                                      <circle 
                                        cx={x} 
                                        cy={y} 
                                        r="6" 
                                        fill={isCys ? '#ca8a04' : '#030712'} 
                                        stroke={isCys ? '#eab308' : '#334155'} 
                                        strokeWidth="1.5"
                                      />
                                      <text x={x} y={y + 3} textAnchor="middle" fill={isCys ? '#ffffff' : '#94a3b8'} className="text-[7px] font-mono font-extrabold">{char}</text>
                                    </g>
                                  );
                                }
                                return null;
                              })}
                            </svg>
                          </div>

                          <div className="text-[10px] text-slate-400 leading-relaxed text-center">
                            Highlights yellow secondary indicators (disulfide residues) and electrostatic clusters.
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-10 space-y-4">
                      <RefreshCw className="w-10 h-10 text-cyan-400 animate-spin mx-auto" />
                      <p className="text-slate-400">Calculating physical biochemistry matrices...</p>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: QUANTUM CIRCUIT */}
              {activeTab === 'circuit' && (
                <div className="space-y-4 font-mono select-text">
                  <div className="flex justify-between items-center bg-slate-950/40 p-3 rounded-xl border border-slate-800">
                    <span className="text-xs text-cyan-400 font-semibold flex items-center gap-2">
                      <Cpu className="w-4 h-4 text-cyan-400" />
                      Quantum State Circuit Mapping Log
                    </span>
                    <button 
                      onClick={() => results && copyToClipboard(results.quantumCircuit)}
                      className="text-[10px] text-slate-300 hover:text-white flex items-center gap-1.5 transition-all bg-slate-800/40 px-3 py-1.5 rounded-lg border border-slate-700/60 cursor-pointer"
                    >
                      <Copy className="w-3 h-3" />
                      {copiedText ? 'Copied' : 'Copy Circuit'}
                    </button>
                  </div>

                  {results ? (
                    <div className="bg-slate-950/20 p-4 rounded-xl border border-slate-800/60 overflow-x-auto text-[11px] text-slate-300 leading-relaxed whitespace-pre font-mono">
                      {results.quantumCircuit}
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <p className="text-slate-500">Awaiting simulation parameters...</p>
                    </div>
                  )}

                  <div className="p-4 bg-cyan-950/10 rounded-xl border border-cyan-800/20 text-xs text-cyan-300 font-sans leading-relaxed flex gap-2">
                    <Info className="w-4 h-4 shrink-0 mt-0.5 text-cyan-400" />
                    <div>
                      <strong>State Representation Explanation</strong>: Each input residue is mapped to qubit polarization vectors. Entangling gates (CNOT) represent inter-residue atomic electrostatic overlap distances, optimized continuously by the classical optimization model.
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: CODON OPTIMIZATION */}
              {activeTab === 'codon' && (
                <div className="space-y-6">
                  {results ? (
                    <div className="space-y-5 font-sans">
                      <div className="bg-slate-800/10 p-5 rounded-2xl border border-slate-800 space-y-4">
                        <div className="flex justify-between items-center border-b border-slate-800/60 pb-3">
                          <div>
                            <h4 className="text-sm font-semibold text-white">mRNA Optimization Results</h4>
                            <p className="text-[11px] text-slate-400">Target Expression Host: <strong className="text-cyan-400">{config.hostOrganism}</strong></p>
                          </div>
                          <span className="text-xs bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 px-3 py-1 rounded-full font-mono font-bold">
                            GC Ratio: {results.codonGCContent.toFixed(1)}%
                          </span>
                        </div>

                        {/* DYNAMIC TRANSCRIPTION STAGES */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                          <div className="space-y-1.5">
                            <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Orig Amino Acids:</span>
                            <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800 select-all truncate text-slate-400">
                              {inputVal}
                            </div>
                          </div>
                          <div className="space-y-1.5">
                            <span className="text-cyan-400 block uppercase tracking-wider text-[10px]">Optimized Codons:</span>
                            <div className="p-3 bg-slate-950/40 rounded-xl border border-slate-800 select-all font-bold text-cyan-300 truncate tracking-wide flex justify-between items-center">
                              <span>{results.codonOptimized}</span>
                              <button 
                                onClick={() => copyToClipboard(results.codonOptimized)}
                                className="ml-2 hover:text-white text-slate-500 transition cursor-pointer"
                                title="Copy DNA sequence"
                              >
                                {copiedText ? 'Copied!' : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="text-xs text-slate-400 leading-relaxed font-sans border-t border-slate-800/80 pt-3">
                          <strong>Codon usage adjustment matrix</strong>: Swapped suboptimal transfer RNAs with high-abundance cognate tRNA sequences. This lowers ribosome pausing times of the synthesized gene, boosting mRNA translation yield during physical bacterial or eukaryotic fermentation up to 4.5x.
                        </div>
                      </div>

                      {/* PHYSICAL PROPERTIES PRE-CALCULATED IN REAL TIME */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-slate-800/20 p-4 rounded-xl border border-slate-800">
                          <span className="text-[10px] text-slate-500 block tracking-wider uppercase font-semibold">Molecular weight</span>
                          <span className="text-lg font-bold font-mono text-cyan-400 inline-block mt-1">
                            {(inputVal.split('').reduce((sum, c) => sum + (AMINO_ACIDS[c]?.weight || 0), 0) + 18.02).toFixed(1)} Da
                          </span>
                        </div>
                        <div className="bg-slate-800/20 p-4 rounded-xl border border-slate-800">
                          <span className="text-[10px] text-slate-500 block tracking-wider uppercase font-semibold">Total Isoelectric point</span>
                          <span className="text-lg font-bold font-mono text-cyan-400 inline-block mt-1">
                            {(inputVal.split('').reduce((sum, c) => sum + (AMINO_ACIDS[c]?.charge || 0), 0) >= 0 ? 'Basic (pH > 7.0)' : 'Acidic (pH < 6.5)' )}
                          </span>
                        </div>
                        <div className="bg-slate-800/20 p-4 rounded-xl border border-slate-800">
                          <span className="text-[10px] text-slate-500 block tracking-wider uppercase font-semibold">Hydrophobicity index</span>
                          <span className="text-lg font-bold font-mono text-cyan-400 inline-block mt-1">
                            {(inputVal.split('').reduce((sum, c) => sum + (AMINO_ACIDS[c]?.hydrophobicity || 0), 0) / inputVal.length).toFixed(2)} KD
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <p className="text-slate-500">No transcription optimized parameters available.</p>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: DEEP SCIENTIFIC REPORT BY AI */}
              {activeTab === 'report' && (
                <div className="space-y-4">
                  {results ? (
                    <div className="bg-slate-950/30 p-5 rounded-2xl border border-slate-800 leading-relaxed max-h-[460px] overflow-y-auto text-slate-200">
                      <ScientificMarkdown text={results.scientificReport} />
                    </div>
                  ) : (
                    <div className="text-center py-10">
                      <p className="text-slate-500">Awaiting biophysics compilation...</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* 3. SCIENTIFIC COPILOT DRAWER (Powered by server-side Gemini chat API) */}
      <footer className="border-t border-slate-800/60 bg-slate-950/80 backdrop-blur-md px-6 py-6 flex flex-col md:flex-row gap-6 mt-auto">
        
        {/* Chat History Drawer (col-span half-width) */}
        <div className="flex-1 space-y-3">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-cyan-400 animate-pulse" />
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-widest">AI Biophysics Companion</h3>
          </div>
          
          <div className="bg-slate-900/40 rounded-2xl border border-slate-850 p-4 h-48 overflow-y-auto space-y-3 font-sans text-xs">
            {chatHistory.map((chat, idx) => (
              <div 
                key={idx} 
                className={`p-3 rounded-xl max-w-[95%] border ${
                  chat.sender === 'user' 
                    ? 'ml-auto bg-slate-800/50 border-slate-700/60 text-cyan-200' 
                    : 'bg-slate-900/30 border border-slate-800/80 text-slate-300'
                }`}
              >
                <div className="font-mono text-[9px] text-slate-500 mb-1 select-none">
                  {chat.sender === 'user' ? 'Scientist Input' : 'Quantum Biophysics Helper'}
                </div>
                <ScientificMarkdown text={chat.text} />
              </div>
            ))}
            {isChatLoading && (
              <div className="text-slate-500 italic flex items-center gap-2">
                <RefreshCw className="w-3 h-3 animate-spin text-cyan-400" />
                Querying computational biology model...
              </div>
            )}
          </div>
        </div>

        {/* Action Panel for Chat Prompt presets or input field */}
        <div className="md:w-96 flex flex-col justify-between gap-3">
          <div className="space-y-1.5">
            <label className="text-[10px] text-slate-500 block font-mono uppercase tracking-widest font-semibold pb-1">Quick Inquiries</label>
            <div className="flex flex-col gap-1.5">
              {[
                { label: 'Suggest mutation structural stabilizers', q: 'Suggest amino acid point mutation shifts to increase chemical folded stability of this sequence.' },
                { label: 'Formulate PyMOL rendering scripts', q: 'Can you write a tailored PyMOL python initialization script to highlight cysteines and secondary alpha helix loops?' },
                { label: 'Contrast prokaryotic codon index', q: 'Please evaluate GC nucleotide ratio of translation and explain ribosomal pause rates.' }
              ].map((p, k) => (
                <button
                  key={k}
                  onClick={() => handleSendChat(p.q)}
                  className="p-2 px-3 rounded-lg bg-slate-900/40 hover:bg-slate-800/50 text-left text-slate-300 hover:text-white border border-slate-800/80 text-[11px] truncate flex items-center justify-between transition-all cursor-pointer"
                >
                  <span>{p.label}</span>
                  <ArrowRight className="w-3 h-3 text-slate-500" />
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 mt-auto">
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
              placeholder="Ask custom bio-physics questions..."
              className="flex-1 bg-slate-900/50 border border-slate-800 rounded-lg px-3 py-2 text-xs outline-none focus:border-cyan-500 text-slate-200"
            />
            <button
              onClick={() => handleSendChat()}
              className="bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-semibold px-4 py-2 rounded-lg text-xs transition duration-150 cursor-pointer shadow-md shadow-cyan-950/20"
            >
              Consult
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
